package com.cfw.movies.manage;


import com.cfw.movies.commons.vo.MoviesResponse;

/**
 * As critical resource.
 * @author Fangwei_Cai
 * @time since 2016年5月15日 下午8:55:59
 */
public class RecommendStatus {

	public static boolean inProcessing = false;
	
	public static MoviesResponse statusMessage = new MoviesResponse();
	
}
