package com.cfw.movies.manage.service.file;

public interface FileHouseService {

}
