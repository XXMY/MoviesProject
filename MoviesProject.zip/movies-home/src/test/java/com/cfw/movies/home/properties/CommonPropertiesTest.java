package com.cfw.movies.home.properties;

import com.cfw.movies.home.Application;
import com.cfw.movies.commons.properties.CommonProperties;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by Duskrain on 2017/5/6.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class CommonPropertiesTest {

    @Test
    public void testProperties(){
        /*System.out.println(CommonProperties.getCommentRmiPort());
        System.out.println(CommonProperties.getCommentRmiHost());*/
    }
}
