package com.cfw.movies.commons.utils;

/**
 * 
 * <常量接口> <功能详细描述>
 * 
 * @author qiaochunguang
 * @version [版本号, Nov 9, 2012]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@SuppressWarnings("serial")
public interface Constant {
	public static final String MOVIE_UPLOAD_ROOT_PATH_CONSTANT = "movie.upload.root.path";

	/**
	 * File upload path of movie
	 */
	// Home
	
}
