package com.cfw.movies.recommend.r;

/**
 * @author Fangwei_Cai
 * @time since 2016年5月14日 下午9:51:08
 */
public class RMysql {

	public final static String DB_NAME = "graduate_design";
	
	public final static String USER_NAME = "grid";
	
	public final static String PASS_WORD = "cfw892";
	
	public final static String HOST  = "192.168.56.1";
	
	public final static String PORT = "3306";
}
